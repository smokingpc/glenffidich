// FtControlDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MOUNTMGR.h"
#include "FtControlDlg.h"
#include <winioctl.h>
#include <ntddvol.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFtControlDlg dialog


CFtControlDlg::CFtControlDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFtControlDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFtControlDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CFtControlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFtControlDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFtControlDlg, CDialog)
	//{{AFX_MSG_MAP(CFtControlDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFtControlDlg message handlers

BOOL CFtControlDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
    m_FtControlHandle = CreateFile(L"\\\\.\\FtControl",GENERIC_READ|GENERIC_WRITE,NULL,NULL,OPEN_EXISTING,NULL,NULL);

    if(m_FtControlHandle == INVALID_HANDLE_VALUE) {

        return FALSE;

    }
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
