// MOUNTMGRDlg.cpp : implementation file
//

#include "stdafx.h"
#include "MOUNTMGR.h"
#include "MOUNTMGRDlg.h"
#include <winioctl.h>
#include <mountmgr.h>
#include "FtControlDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMOUNTMGRDlg dialog

CMOUNTMGRDlg::CMOUNTMGRDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMOUNTMGRDlg::IDD, pParent), m_MtnMgrHandle(INVALID_HANDLE_VALUE)
{
	//{{AFX_DATA_INIT(CMOUNTMGRDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMOUNTMGRDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMOUNTMGRDlg)
	DDX_Control(pDX, IDC_LIST_MOUNTPOINTS, m_MountList);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMOUNTMGRDlg, CDialog)
	//{{AFX_MSG_MAP(CMOUNTMGRDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_FT_CONTROL, OnButtonFtControl)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMOUNTMGRDlg message handlers

BOOL CMOUNTMGRDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

    m_MtnMgrHandle = CreateFile(MOUNTMGR_DOS_DEVICE_NAME,GENERIC_READ|GENERIC_WRITE,NULL,NULL,OPEN_EXISTING,NULL,NULL);

    if(m_MtnMgrHandle == INVALID_HANDLE_VALUE) {

        return FALSE;

    }
	
    m_MountList.SetExtendedStyle(LVS_EX_FULLROWSELECT);	

    CRect rect;
    CSize size;

    m_MountList.GetClientRect(rect);

    size = rect.Size();

    UINT portion = size.cx/3;

    m_MountList.InsertColumn(0,L"Symbolic Link",LVCFMT_LEFT,portion);
    m_MountList.InsertColumn(1,L"Unique Id",LVCFMT_LEFT,portion);
    m_MountList.InsertColumn(2,L"Device Name",LVCFMT_LEFT,portion);

    ListMountPoints();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMOUNTMGRDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMOUNTMGRDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMOUNTMGRDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMOUNTMGRDlg::ListMountPoints()
{
    DWORD bytesReturned;
    PUCHAR pBytes = new unsigned char[10000];
    PMOUNTMGR_MOUNT_POINTS pMntPoints = (PMOUNTMGR_MOUNT_POINTS) pBytes;
    MOUNTMGR_MOUNT_POINT mntPoint;

    if(!pBytes) {

        return;

    }

    memset(pMntPoints,0,10000);
    memset(&mntPoint,0,sizeof(MOUNTMGR_MOUNT_POINT));

    pMntPoints->Size = 10000;

    if(DeviceIoControl(m_MtnMgrHandle,IOCTL_MOUNTMGR_QUERY_POINTS,&mntPoint,sizeof(MOUNTMGR_MOUNT_POINT),
        pMntPoints,10000,&bytesReturned,NULL)) {

        if(bytesReturned && pMntPoints->Size && pMntPoints->NumberOfMountPoints) {

            for(ULONG index = 0; index < pMntPoints->NumberOfMountPoints; index++) {

                int     insertIndex = 0;
                CString uniqueId;

                CString symbolicName((PWCHAR) &pBytes[pMntPoints->MountPoints[index].SymbolicLinkNameOffset],pMntPoints->MountPoints[index].SymbolicLinkNameLength/sizeof(WCHAR));

                PWCHAR px = (PWCHAR) (&pBytes[pMntPoints->MountPoints[index].UniqueIdOffset]);
                BOOLEAN bString = (L'\\' != *px);

                if(!bString) {

                    CString id((PWCHAR) &pBytes[pMntPoints->MountPoints[index].UniqueIdOffset],pMntPoints->MountPoints[index].UniqueIdLength/sizeof(WCHAR));

                    uniqueId = id;

                } else {

                    BOOLEAN dmioDisk = FALSE;
                    ULONG offset = pMntPoints->MountPoints[index].UniqueIdOffset;
                    CString   number;
                    WCHAR buffer[20];

                    uniqueId.Empty();

                    for(ULONG count = 0; count < pMntPoints->MountPoints[index].UniqueIdLength; count++) {

                        number += _itow(pBytes[offset+count],buffer,16);

                        if(!dmioDisk) {

                            CString digit(pBytes[offset+count],1);

                            uniqueId += digit;

                        } else {
                            
                            uniqueId += _itow(pBytes[offset+count],buffer,16);

                        }

                        if(uniqueId == L"DMIO:ID:") {

                            dmioDisk = TRUE;
 
                        }
                    }

                    if(!dmioDisk) {
#if 1
                        PULONG pLong = (PULONG) (&pBytes[offset]);

                        number.Format(L"BASIC:Signature %x - Offset %x - Length %x",pLong[0],pLong[1],pLong[2]);
                        uniqueId = number;
#else
                        uniqueId = number;
#endif

                    } else {

                        GUID* pGuid = (GUID*) (&pBytes[offset+sizeof("DMIO:ID:")-sizeof(CHAR)]);
                        uniqueId.Format(L"DMIO:ID:{%08x-%04x-%04x-%2x%2x-%02x%02x%02x%02x%02x%02x}",pGuid->Data1,pGuid->Data2,pGuid->Data3,
                            pGuid->Data4[0],pGuid->Data4[1],pGuid->Data4[2],pGuid->Data4[3],
                            pGuid->Data4[4],pGuid->Data4[5],pGuid->Data4[6],pGuid->Data4[7]);
                                        
                    }
                }

                CString deviceName((PWCHAR) &pBytes[pMntPoints->MountPoints[index].DeviceNameOffset],pMntPoints->MountPoints[index].DeviceNameLength/sizeof(WCHAR));

	            insertIndex = m_MountList.InsertItem(insertIndex,(LPCTSTR) symbolicName);

	            m_MountList.SetItemText(insertIndex,1,(LPCTSTR) uniqueId);

	            m_MountList.SetItemText(insertIndex,2,(LPCTSTR) deviceName);
            }

        }
    } else {

        DWORD error = GetLastError();
        CString text;

        text.Format(L"Could not get mount points. error = %d.\n",error);
        AfxMessageBox(text,MB_OK|MB_ICONSTOP);


    }

    delete []pBytes;
}

void CMOUNTMGRDlg::OnButtonFtControl() 
{
	CFtControlDlg dlg;

    dlg.DoModal();

	
}
