// MOUNTMGRDlg.h : header file
//

#if !defined(AFX_MOUNTMGRDLG_H__DE4D26B1_D249_4D34_82F5_39C9AED75AC8__INCLUDED_)
#define AFX_MOUNTMGRDLG_H__DE4D26B1_D249_4D34_82F5_39C9AED75AC8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMOUNTMGRDlg dialog

class CMOUNTMGRDlg : public CDialog
{
// Construction
public:
	void ListMountPoints();
	HANDLE m_MtnMgrHandle;
	CMOUNTMGRDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMOUNTMGRDlg)
	enum { IDD = IDD_MOUNTMGR_DIALOG };
	CListCtrl	m_MountList;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMOUNTMGRDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMOUNTMGRDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonFtControl();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MOUNTMGRDLG_H__DE4D26B1_D249_4D34_82F5_39C9AED75AC8__INCLUDED_)
