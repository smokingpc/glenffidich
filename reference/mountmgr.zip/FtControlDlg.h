#if !defined(AFX_FTCONTROLDLG_H__3DCDB286_6489_41BC_A0B3_CCA8C7E9A8F2__INCLUDED_)
#define AFX_FTCONTROLDLG_H__3DCDB286_6489_41BC_A0B3_CCA8C7E9A8F2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FtControlDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFtControlDlg dialog

class CFtControlDlg : public CDialog
{
// Construction
public:
	HANDLE m_FtControlHandle;
	CFtControlDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFtControlDlg)
	enum { IDD = IDD_DIALOG_FT_CONTROL };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFtControlDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFtControlDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FTCONTROLDLG_H__3DCDB286_6489_41BC_A0B3_CCA8C7E9A8F2__INCLUDED_)
