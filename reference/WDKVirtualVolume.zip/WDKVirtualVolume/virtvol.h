/****************************** Module Header ******************************\
* Module Name:  virtvol.h
* Project:      CppWDKVirtualVolume
* Copyright (c) Microsoft Corporation.
* 
* Abstract:
* 
* This is the Virtvol sample driver.  This version of the driver has been
* modified to support the driver frameworks. This driver basically creates
* a nonpaged pool and exposes that as a storage media. User can
* find the device in the disk manager and format the media to use
* as FAT or NTFS volume.
* 
* Environment:
* 
* Kernel mode only.
* 
* This source is subject to the Microsoft Public License.
* See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL.
* All other rights reserved.
* 
* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
* EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
\***************************************************************************/
#ifndef _VIRTVOL_H_
#define _VIRTVOL_H_
#pragma warning(disable:4201)  // nameless struct/union warning
#include <ntddk.h>
#include <ntdddisk.h>
#include <ntddvol.h>
#include <mountdev.h>
#include <mountmgr.h>
#pragma warning(default:4201)
#include <wdf.h>
#define NTSTRSAFE_LIB
#include <ntstrsafe.h>
#include <initguid.h>
#include <devguid.h>
#define NT_DEVICE_NAME                  L"\\Device\\Virtvol"
#define DOS_DEVICE_NAME                 L"\\DosDevices\\"
#define VIRTVOL_TAG                     'VtrV'  // "VrtV"
#define DOS_DEVNAME_LENGTH              (sizeof(DOS_DEVICE_NAME)+sizeof(WCHAR)*10)
#define NT_DEVNAME_LENGTH               (sizeof(NT_DEVICE_NAME)+sizeof(WCHAR)*10)
#define DRIVE_LETTER_LENGTH             (sizeof(WCHAR)*10)
#define DRIVE_LETTER_BUFFER_SIZE        10
#define DOS_DEVNAME_BUFFER_SIZE         (sizeof(DOS_DEVICE_NAME) / 2) + 10
#define NT_DEVNAME_BUFFER_SIZE         (sizeof(NT_DEVICE_NAME) / 2) + 10
#define VIRTVOL_MEDIA_TYPE              0xF8
#define DIR_ENTRIES_PER_SECTOR          16
#define DEFAULT_VOL_SIZE               (1024*1024)     // 1 MB
#define DEFAULT_ROOT_DIR_ENTRIES        512
#define DEFAULT_SECTORS_PER_CLUSTER     2
#define DEFAULT_DRIVE_LETTER            L"Z:"
DEFINE_GUID(GUID_VIRTVOL_UNIQUE_ID, 0x7603f260, 0x142a, 0x11d4, 0xac, 0x76, 0x80, 0x6d, 0x61, 0x72, 0x69, 0x6f);
#define GUID_VIRTVOL_UNIQUE_ID_STR     L"7603f260-142a-11d4-ac67-806d6172696f"
typedef struct _VIRTVOL_INFO {
    ULONG   StorSize;           // Virtvol size in bytes
    ULONG   RootDirEntries;     // No. of root directory entries
    ULONG   SectorsPerCluster;  // Sectors per cluster
    UNICODE_STRING DriveLetter; // Drive letter to be used
} VIRTVOL_INFO, *PVIRTVOL_INFO;
typedef struct _DEVICE_EXTENSION {
    PUCHAR                          VolumeImage;      // Pointer to beginning of volume image
    DISK_GEOMETRY                   DiskGeometry;     // Drive parameters built by Virtvol
    STORAGE_HOTPLUG_INFO            StorHotPlug;
    DRIVE_LAYOUT_INFORMATION_EX     DriveLayoutInfo;
    ULONG                           StorNumber;
    VIRTVOL_INFO                    VirtvolRegInfo;      // Volume parameters from the registry
    GUID                            UniqueIdGuid;
    UNICODE_STRING                  SymbolicLink;     // Dos symbolic name; Drive letter
    UNICODE_STRING                  DeviceInterfaceSymbolicLink;   // The symbolic link name that the OS assigned to a device interface that the driver registered for a specified device.   
    UNICODE_STRING                  NtDeviceName;     // Nt device name
    WCHAR                           DriveLetterBuffer[DRIVE_LETTER_BUFFER_SIZE];
    WCHAR                           DosDeviceNameBuffer[DOS_DEVNAME_BUFFER_SIZE];
    WCHAR                           NtDeviceNameBuffer[DOS_DEVNAME_BUFFER_SIZE];
} DEVICE_EXTENSION, *PDEVICE_EXTENSION;
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(DEVICE_EXTENSION, DeviceGetExtension)
typedef struct _QUEUE_EXTENSION {
    PDEVICE_EXTENSION DeviceExtension;
} QUEUE_EXTENSION, *PQUEUE_EXTENSION;
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(QUEUE_EXTENSION, QueueGetExtension)
#pragma pack(1)
typedef struct  _BOOT_SECTOR
{
    UCHAR       bsJump[3];          // x86 jmp instruction, checked by FS
    CCHAR       bsOemName[8];       // OEM name of formatter
    USHORT      bsBytesPerSec;      // Bytes per Sector
    UCHAR       bsSecPerClus;       // Sectors per Cluster
    USHORT      bsResSectors;       // Reserved Sectors
    UCHAR       bsFATs;             // Number of FATs - we always use 1
    USHORT      bsRootDirEnts;      // Number of Root Dir Entries
    USHORT      bsSectors;          // Number of Sectors
    UCHAR       bsMedia;            // Media type - we use VIRTVOL_MEDIA_TYPE
    USHORT      bsFATsecs;          // Number of FAT sectors
    USHORT      bsSecPerTrack;      // Sectors per Track - we use 32
    USHORT      bsHeads;            // Number of Heads - we use 2
    ULONG       bsHiddenSecs;       // Hidden Sectors - we set to 0
    ULONG       bsHugeSectors;      // Number of Sectors if > 32 MB size
    UCHAR       bsDriveNumber;      // Drive Number - not used
    UCHAR       bsReserved1;        // Reserved
    UCHAR       bsBootSignature;    // New Format Boot Signature - 0x29
    ULONG       bsVolumeID;         // VolumeID - set to 0x12345678
    CCHAR       bsLabel[11];        // Label - set to Virtvol
    CCHAR       bsFileSystemType[8];// File System Type - FAT12 or FAT16
    CCHAR       bsReserved2[448];   // Reserved
    UCHAR       bsSig2[2];          // Originial Boot Signature - 0x55, 0xAA
}   BOOT_SECTOR, *PBOOT_SECTOR;
typedef struct  _DIR_ENTRY
{
    UCHAR       deName[8];          // File Name
    UCHAR       deExtension[3];     // File Extension
    UCHAR       deAttributes;       // File Attributes
    UCHAR       deReserved;         // Reserved
    USHORT      deTime;             // File Time
    USHORT      deDate;             // File Date
    USHORT      deStartCluster;     // First Cluster of file
    ULONG       deFileSize;         // File Length
}   DIR_ENTRY, *PDIR_ENTRY;
#pragma pack()
// Directory Entry Attributes
#define DIR_ATTR_READONLY   0x01
#define DIR_ATTR_HIDDEN     0x02
#define DIR_ATTR_SYSTEM     0x04
#define DIR_ATTR_VOLUME     0x08
#define DIR_ATTR_DIRECTORY  0x10
#define DIR_ATTR_ARCHIVE    0x20
DRIVER_INITIALIZE DriverEntry;
EVT_WDF_DRIVER_DEVICE_ADD VirtVolEvtDeviceAdd;
EVT_WDF_DRIVER_UNLOAD VirtVolEvtDriverUnload;
EVT_WDF_DEVICE_PREPARE_HARDWARE VirtVolEvtDevicePrepareHardware;
EVT_WDF_DEVICE_RELEASE_HARDWARE VirtVolEvtDeviceReleaseHardware;
EVT_WDF_DEVICE_D0_ENTRY VirtVolEvtDeviceD0Entry;
EVT_WDF_DEVICE_CONTEXT_CLEANUP VirtVolEvtDeviceContextCleanup;
EVT_WDF_IO_QUEUE_IO_READ VirtVolEvtIoRead;
EVT_WDF_IO_QUEUE_IO_WRITE VirtVolEvtIoWrite;
EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL VirtVolEvtIoDeviceControl;
VOID VirtVolQueryVolumeRegParameters(__in PWSTR RegistryPath, __in PVIRTVOL_INFO VirtvolRegInfo);
NTSTATUS VirtVolFormatVolume(IN PDEVICE_EXTENSION DeviceExtension);
BOOLEAN VirtVolCheckParameters(IN PDEVICE_EXTENSION devExt, IN LARGE_INTEGER ByteOffset, IN size_t Length);
NTSTATUS RegisterMountMgr(PDEVICE_EXTENSION devExt); 
VOID RegisterMountMgrWorkItem(WDFWORKITEM WorkItem);
NTSTATUS CreateMountMgrWorkItem(WDFDEVICE device);
EVT_WDF_OBJECT_CONTEXT_CLEANUP EvtForwardProgressRequestCleanup;
EVT_WDF_OBJECT_CONTEXT_DESTROY EvtForwardProgressRequestDestroy;
EVT_WDF_IO_WDM_IRP_FOR_FORWARD_PROGRESS EvtIoWdmIrpForForwardProgress;
EVT_WDF_IO_ALLOCATE_RESOURCES_FOR_RESERVED_REQUEST EvtIoAllocateResourcesForReservedRequest;
EVT_WDF_IO_ALLOCATE_REQUEST_RESOURCES EvtIoAllocateResources;
#endif    // _VIRTVOL_H_
